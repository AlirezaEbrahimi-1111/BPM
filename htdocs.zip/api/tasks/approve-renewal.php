<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: https://bpm.computeryekta.com');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/auth.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/middleware.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/TaskManager.php';

try {
    $user_id = requireAuth();
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data['request_id'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'شناسه درخواست الزامی است']);
        exit;
    }

    $database = new Database();
    $db = $database->getConnection();
    $taskManager = new TaskManager($db);

    $result = $taskManager->approvePeriodRenewal(
        intval($data['request_id']),
        $user_id,
        trim($data['notes'] ?? '')
    );

    echo json_encode($result, JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'خطای سرور']);
    error_log("approve-renewal error: " . $e->getMessage());
}