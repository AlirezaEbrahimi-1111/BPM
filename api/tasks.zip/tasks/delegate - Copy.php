<?php
ob_start();  // buffering برای جلوگیری از خروجی ناقص
error_reporting(E_ALL);  // errorها رو نشون بده
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/auth.php';
require_once '../../includes/TaskManager.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/middleware.php';
require_once '../../includes/Notification.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'متد غیرمجاز']);
    exit;
}

try {
    $user_id = requireAuth();
    $input = json_decode(file_get_contents('php://input'), true);

    if (empty($input['task_id']) || empty($input['to_user_id'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'شناسه کار و کاربر مقصد الزامی است']);
        exit;
    }

    $database = new Database();
    $db = $database->getConnection();
    $taskManager = new TaskManager($db);

    // ✅ چک دسترسی: فقط assignee یا creator
    $task = $taskManager->getTask($input['task_id']);
    if (!$task || ($task['assignee_id'] != $user_id && $task['creator_id'] != $user_id)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
        exit;
    }
    // ✅ مورد ۱: خواندن پارامتر silent
    $silent = isset($input['silent']) && $input['silent'] === true;

    if ($silent) {
        // ارجاع بدون تاریخچه: فقط assignee_id را تغییر بده
        $stmt = $db->prepare("
            UPDATE tasks 
            SET assignee_id = ?, 
                status = 'delegated',
                updated_at = NOW() 
            WHERE id = ?
        ");
        $stmt->execute([$input['to_user_id'], $input['task_id']]);

        $result = ['success' => true, 'message' => 'کار با موفقیت ارجاع داده شد'];
    } else {
        $result = $taskManager->delegateTask(
            $input['task_id'],
            $input['to_user_id'],
            $user_id,
            $input['notes'] ?? ''
        );
    }
    if ($result['success']) {

        $notif = new Notification($db);
        // ✅ اصلاح: چک notes ایمن
        $notes = $input['notes'] ?? '';
        if (empty($notes)) {
            $name = 'کاربر';  // نام پیش‌فرض
        } else {
            $parts = explode(':', $notes, 2);  // حداکثر ۲ قسمت
            $name = trim($parts[0]) ?: 'کاربر';
        }
        $notif->create([
            'to_user_id' => $input['to_user_id'],
            'title' => "کار جدید ارجاع شده",
            'message' => "کار «{$task['title']}» توسط {$name} به شما ارجاع داده شد",
            'type' => "warning",
            'related_type' => 'task',  // ✅ اضافه شد
            'related_id' => $input['task_id'],  // ✅ اضافه شد
            'link' => "../pages/task-detail.php?id={$input['task_id']}"
        ]);

        http_response_code(200);
    } else {
        http_response_code(400);
    }

    echo json_encode($result);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'خطای داخلی سرور']);
    error_log("Delegate task error: " . $e->getMessage());
}
?>