<?php
// ==================================================
// test-request-deadline-debug.php
// تست کامل برای دیباگ ساخت approval chain
// ==================================================

header('Content-Type: text/plain; charset=utf-8');

require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';

$task_id = 984;

$database = new Database();
$db = $database->getConnection();

echo "========================================\n";
echo "🔍 تست ساخت Approval Chain\n";
echo "========================================\n\n";

// 1. دریافت اطلاعات کار
echo "=== 1. اطلاعات کار ===\n";
$stmt = $db->prepare("SELECT id, assignee_id, creator_id, deadline FROM tasks WHERE id = ?");
$stmt->execute([$task_id]);
$task = $stmt->fetch(PDO::FETCH_ASSOC);
print_r($task);
echo "\n";

// 2. دریافت زنجیره delegation
echo "=== 2. زنجیره Delegation ===\n";
$stmt = $db->prepare("
    SELECT from_user_id, to_user_id, action, created_at
    FROM task_history 
    WHERE task_id = ? 
    AND action IN ('created', 'delegated')
    ORDER BY created_at ASC
");
$stmt->execute([$task_id]);
$delegation_chain = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "تعداد: " . count($delegation_chain) . "\n";
print_r($delegation_chain);
echo "\n";

// 3. ساخت approval_chain
echo "=== 3. ساخت Approval Chain ===\n";
$approval_chain = [];

if (!empty($delegation_chain)) {
    echo "✅ Delegation chain وجود دارد\n";
    
    // آخرین delegation را پیدا کن
    $last_delegation = end($delegation_chain);
    echo "آخرین delegation:\n";
    print_r($last_delegation);
    
    if ($last_delegation && isset($last_delegation['from_user_id'])) {
        echo "✅ آخرین delegator (from_user_id): " . $last_delegation['from_user_id'] . "\n";
        $approval_chain[] = $last_delegation['from_user_id'];
    } else {
        echo "❌ last_delegation یا from_user_id وجود ندارد!\n";
    }
} else {
    echo "⚠️ Delegation chain خالی است\n";
}

// creator را اضافه کن
echo "✅ اضافه کردن creator: " . $task['creator_id'] . "\n";
$approval_chain[] = $task['creator_id'];

// حذف تکراری‌ها
$approval_chain = array_unique($approval_chain);
$approval_chain = array_values($approval_chain);

echo "\n📊 Approval Chain نهایی:\n";
print_r($approval_chain);
echo "JSON: " . json_encode($approval_chain) . "\n";

// اولین approver
$current_approver_id = $approval_chain[0];
echo "\n👤 Current Approver ID: " . $current_approver_id . "\n";

// 4. شبیه‌سازی INSERT
echo "\n=== 4. شبیه‌سازی INSERT ===\n";
echo "INSERT INTO deadline_requests VALUES:\n";
echo "  task_id: $task_id\n";
echo "  requested_by: " . $task['assignee_id'] . "\n";
echo "  current_approver_id: $current_approver_id\n";
echo "  approval_chain: " . json_encode($approval_chain) . "\n";

echo "\n✅ تست کامل شد!\n";
?>