<?php
ob_start();
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/auth.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/TaskManager.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/middleware.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/Notification.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'متد غیرمجاز']);
    exit;
}

try {
    $user_id = requireAuth();
    $input = json_decode(file_get_contents('php://input'), true);

    if (empty($input['task_id']) || empty($input['to_user_id'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'شناسه کار و کاربر مقصد الزامی است']);
        exit;
    }

    $database = new Database();
    $db = $database->getConnection();
    $taskManager = new TaskManager($db);

    $task = $taskManager->getTask($input['task_id']);
    if (!$task || ($task['assignee_id'] != $user_id && $task['creator_id'] != $user_id)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
        exit;
    }

    // ارجاع (همیشه با ثبت تاریخچه)
    $result = $taskManager->delegateTask(
        $input['task_id'],
        $input['to_user_id'],
        $user_id,
        $input['notes'] ?? ''
    );

    if ($result['success']) {

        // ✅ مدیریت دید تاریخچه
        $shareHistory = isset($input['share_history']) ? (bool)$input['share_history'] : true;

        if (!$shareHistory) {
            // تیک غیرفعال → کاربر جدید فقط از الان به بعد ببیند
            $stmt = $db->prepare("
                INSERT INTO task_history_visibility (task_id, user_id, visible_from)
                VALUES (?, ?, NOW())
                ON DUPLICATE KEY UPDATE visible_from = NOW()
            ");
            $stmt->execute([$input['task_id'], $input['to_user_id']]);
        } else {
            // تیک فعال → اگر قبلاً محدودیت داشت، حذفش کن
            $stmt = $db->prepare("
                DELETE FROM task_history_visibility 
                WHERE task_id = ? AND user_id = ?
            ");
            $stmt->execute([$input['task_id'], $input['to_user_id']]);
        }

        // نوتیفیکیشن
        $notif = new Notification($db);
        $notes = $input['notes'] ?? '';
        if (empty($notes)) {
            $name = 'کاربر';
        } else {
            $parts = explode(':', $notes, 2);
            $name = trim($parts[0]) ?: 'کاربر';
        }
        $notif->create([
            'to_user_id' => $input['to_user_id'],
            'title' => "کار جدید ارجاع شده",
            'message' => "کار «{$task['title']}» توسط {$name} به شما ارجاع داده شد",
            'type' => "warning",
            'related_type' => 'task',
            'related_id' => $input['task_id'],
            'link' => "../pages/task-detail.php?id={$input['task_id']}"
        ]);

        http_response_code(200);
    } else {
        http_response_code(400);
    }

    echo json_encode($result);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'خطای داخلی سرور']);
    error_log("Delegate task error: " . $e->getMessage());
}
?>