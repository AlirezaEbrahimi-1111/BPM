<?php
header('Content-Type: application/json; charset=utf-8');

try {
    require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';
    require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/auth.php';

    // ========================================
    // تابع کمکی: آیا کاربر اجازه ارسال یادآوری دارد؟
    // شرط 1: کاربر creator تسک باشد
    // شرط 2: یا در زنجیره ارجاعات، آخرین نفری باشد که کار را واگذار کرده
    // ========================================
    function canUserRemind($db, $user_id, $task)
    {
        // شرط اولیه: کاربر جاری نباید مسئول انجام کار باشد
        if ($task['assignee_id'] == $user_id) {
            return false;
        }

        // شرط 1: کاربر جاری تعریف‌کننده (creator) تسک باشد
        if ($task['creator_id'] == $user_id) {
            return true;
        }

        // شرط 2: آخرین واگذارکننده در زنجیره ارجاعات باشد
        // آخرین رکورد assigned/delegated در task_history که from_user_id = کاربر جاری
        $stmt = $db->prepare("
            SELECT id FROM task_history 
            WHERE task_id = ? 
            AND action IN ('assigned', 'delegated') 
            AND from_user_id = ?
            ORDER BY created_at DESC 
            LIMIT 1
        ");
        $stmt->execute([$task['id'], $user_id]);
        $lastDelegation = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$lastDelegation) {
            return false;
        }

        // بررسی: آیا بعد از واگذاری این کاربر، شخص دیگری هم واگذار کرده؟
        // اگر بله، یعنی این کاربر دیگر آخرین واگذارکننده نیست
        $stmt = $db->prepare("
            SELECT id FROM task_history 
            WHERE task_id = ? 
            AND action IN ('assigned', 'delegated') 
            AND from_user_id != ?
            AND id > ?
            ORDER BY created_at DESC 
            LIMIT 1
        ");
        $stmt->execute([$task['id'], $user_id, $lastDelegation['id']]);
        $laterDelegation = $stmt->fetch(PDO::FETCH_ASSOC);

        // اگر کسی بعد از این کاربر واگذار نکرده، پس این کاربر آخرین واگذارکننده است
        return !$laterDelegation;
    }

    // استخراج توکن
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    if (empty($authHeader) || !preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
        echo json_encode(['success' => false, 'message' => 'توکن نامعتبر'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $token = $matches[1];
    $auth = new Auth();
    $user_id = $auth->validateToken($token);

    if (!$user_id) {
        echo json_encode(['success' => false, 'message' => 'توکن نامعتبر است'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $database = new Database();
    $db = $database->getConnection();

    if (!$db) {
        throw new Exception('خطا در اتصال به دیتابیس');
    }

    // دریافت اطلاعات کاربر
    $stmt = $db->prepare("SELECT id, role, organization_id FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !in_array($user['role'], ['manager', 'supervisor'])) {
        echo json_encode([
            'success' => false,
            'message' => 'دسترسی غیرمجاز - نقش شما: ' . ($user['role'] ?? 'نامشخص')
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ========================================
    // پارامتر: آیا کارهای خود کاربر هم نمایش داده شود؟
    // ========================================
    $include_my_tasks = isset($_GET['include_my_tasks']) && $_GET['include_my_tasks'] == '1';

    // ========================================
    // 🔵 SUPERVISOR: همه تسک‌ها
    // ========================================
    if ($user['role'] === 'supervisor') {
        $sql = "
            SELECT 
                t.id, t.title, t.description, t.task_type, t.priority, t.status,
                t.due_date, t.created_at, t.creator_id, t.assignee_id, t.deadline,
                CONCAT(COALESCE(creator.first_name, ''), ' ', COALESCE(creator.last_name, '')) as creator_name,
                CONCAT(COALESCE(assignee.first_name, ''), ' ', COALESCE(assignee.last_name, '')) as assignee_name
            FROM tasks t
            LEFT JOIN users creator ON t.creator_id = creator.id
            LEFT JOIN users assignee ON t.assignee_id = assignee.id
            WHERE t.is_deleted = 0 AND t.organization_id = ?
            ORDER BY 
                CASE WHEN t.due_date < CURDATE() THEN 1 ELSE 2 END,
                t.priority = 'high' DESC,
                t.created_at DESC
        ";
        $stmt = $db->prepare($sql);
        $stmt->execute([$user['organization_id']]);
        $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // ========================================
        // بررسی دسترسی یادآوری برای هر تسک
        // شرط: کاربر جاری creator باشد یا آخرین واگذارکننده در زنجیره ارجاعات
        // ========================================
        foreach ($tasks as &$task) {
            $task['can_remind'] = canUserRemind($db, $user_id, $task);
        }
        unset($task);

        echo json_encode([
            'success' => true,
            'tasks' => $tasks,
            'count' => count($tasks),
            'user_role' => 'supervisor',
            'message' => 'نمایش تمام تسک‌ها'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ========================================
    // 🟢 MANAGER: فقط تسک‌های زیردستان
    // ========================================

    // مرحله 1: پیدا کردن زیردستان مستقیم
    // کاربرانی که manager_code آنها برابر با id کاربر جاری است
    $stmt = $db->prepare("
        SELECT id 
        FROM users 
        WHERE manager_code = ? 
        AND is_active = 1
    ");
    $stmt->execute([(string) $user_id]); // تبدیل به string برای مقایسه صحیح
    $direct_subordinates = $stmt->fetchAll(PDO::FETCH_COLUMN);

    error_log("👥 User $user_id - Direct subordinates: " . implode(',', $direct_subordinates));

    // مرحله 2: پیدا کردن زیردستان غیرمستقیم (سطح دوم)
    $indirect_subordinates = [];
    if (!empty($direct_subordinates)) {
        // تبدیل id ها به string برای مقایسه با manager_code
        $string_ids = array_map('strval', $direct_subordinates);
        $placeholders = str_repeat('?,', count($string_ids) - 1) . '?';

        $stmt = $db->prepare("
            SELECT id 
            FROM users 
            WHERE manager_code IN ($placeholders) 
            AND is_active = 1
        ");
        $stmt->execute($string_ids);
        $indirect_subordinates = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    error_log("👥 User $user_id - Indirect subordinates: " . implode(',', $indirect_subordinates));

    // ترکیب زیردستان + همیشه خود کاربر
    $all_subordinates = array_merge($direct_subordinates, $indirect_subordinates);
    $all_subordinates[] = $user_id;

    // حذف تکراری‌ها
    $all_subordinates = array_unique($all_subordinates);

    error_log("👥 User $user_id - Total to query: " . implode(',', $all_subordinates));

    // اگر هیچ زیردستی ندارد
    if (empty($all_subordinates)) {
        echo json_encode([
            'success' => true,
            'tasks' => [],
            'count' => 0,
            'user_role' => 'manager',
            'subordinates_count' => 0,
            'message' => 'شما هیچ زیردستی ندارید'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // مرحله 3: دریافت تسک‌ها
    $placeholders = str_repeat('?,', count($all_subordinates) - 1) . '?';

    $sql = "
        SELECT 
            t.id, t.title, t.description, t.task_type, t.priority, t.status,
            t.due_date, t.created_at, t.creator_id, t.assignee_id, t.deadline,
            CONCAT(COALESCE(creator.first_name, ''), ' ', COALESCE(creator.last_name, '')) as creator_name,
            CONCAT(COALESCE(assignee.first_name, ''), ' ', COALESCE(assignee.last_name, '')) as assignee_name
        FROM tasks t
        LEFT JOIN users creator ON t.creator_id = creator.id
        LEFT JOIN users assignee ON t.assignee_id = assignee.id
        WHERE t.is_deleted = 0
        AND (t.creator_id IN ($placeholders) OR t.assignee_id IN ($placeholders))
        ORDER BY 
            CASE WHEN t.due_date < CURDATE() THEN 1 ELSE 2 END,
            t.priority = 'high' DESC,
            t.created_at DESC
    ";

    $params = array_merge($all_subordinates, $all_subordinates);
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // ========================================
    // بررسی دسترسی یادآوری برای هر تسک
    // ========================================
    foreach ($tasks as &$task) {
        $task['can_remind'] = canUserRemind($db, $user_id, $task);
    }
    unset($task);

    echo json_encode([
        'success' => true,
        'tasks' => $tasks,
        'count' => count($tasks),
        'user_role' => 'manager',
        'subordinates_count' => count($all_subordinates),
        'include_my_tasks' => $include_my_tasks
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    error_log("❌ Overview API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطای سرور',
        'error' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>